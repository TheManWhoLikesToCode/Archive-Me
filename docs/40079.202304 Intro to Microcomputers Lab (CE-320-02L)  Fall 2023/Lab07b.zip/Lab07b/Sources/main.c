#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */

#include "main_asm.h" /* interface to the assembly module */

// constants for enabling digits
#define DIGIT4 0x0E
#define DIGIT3 0x0D
#define DIGIT2 0x0B
#define DIGIT1 0x07

// constants for reading switches
#define SW2 8
#define SW3 4
#define SW4 2
#define SW5 1

// hold each 7-segment digit's value
unsigned char dig4;
unsigned char dig3;
unsigned char dig2;
unsigned char dig1;

// previous value of switch
unsigned char last;

// assembly subroutine to wait
void pause10usec(int);

void main(void) {
  /* put your own code here */
  // Note, the stack is initialized in datapage.c
  PORTB = 0;
  DDRB = 0xFF;
  
  DDRP = 0xFF;
  
  DDRH = 0x00;
  
  dig4 = 1;
  dig3 = 1;
  dig2 = 1;  
  dig1 = 1;
  
  last = 0x0f;


  for(;;) {
    PORTB = dig4;
    PTP = DIGIT4;
    pause10usec(500);    
    if ((PTH & SW2) == 0) {
     
      if ((last & SW2) == SW2) {
        
        dig4 = dig4 << 1;
        if (dig4 == 0){
          dig4++;
        }
      } 
      last &= (0xFF-SW2);
    } else {
      last |= SW2; 
    }

    /*******************************************/
    PORTB = dig3;
    PTP = DIGIT3;
    pause10usec(500);    
    if ((PTH & SW3) == 0) {
     
      if ((last & SW3) == SW3) {
        
        dig3 = dig3 << 1;
        if (dig3 == 0){
          dig3++;
        }
      } 
      last &= (0xFF-SW3);
    } else {
      last |= SW3; 
    }
    
    /*******************************************/
    PORTB = dig2;
    PTP = DIGIT2;
    pause10usec(500);    
    if ((PTH & SW4) == 0) {
     
      if ((last & SW4) == SW4) {
        
        dig2 = dig2 << 1;
        if (dig2 == 0){
          dig2++;
        }
      } 
      last &= (0xFF-SW4);
    } else {
      last |= SW4; 
    }
    
    /*******************************************/
    PORTB = dig1;
    PTP = DIGIT1;
    pause10usec(500);    
    if ((PTH & SW5) == 0) {
     
      if ((last & SW5) == SW5) {
        
        dig1 = dig1 << 1;
        if (dig1 == 0){
          dig1++;
        }
      } 
      last &= (0xFF-SW5);
    } else {
      last |= SW5; 
    }    
    
  } /* loop forever */
  /* please make sure that you never leave main */
}

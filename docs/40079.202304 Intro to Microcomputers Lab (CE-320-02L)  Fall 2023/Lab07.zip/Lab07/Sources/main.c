#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */

#include "main_asm.h" /* interface to the assembly module */

#define DEBOUNCE 60   // delay required to debouce Dragon12 pushbuttons

int i;
char buttonDown, buttonUp;

void main(void) {
  /* put your own code here */
  
  PORTB = 0x01;       // set top LED of display
  DDRB = 0xFF;        // ... and enable the LED 7-segment outputs
  
  PTP &= 0xFB;        // enable DSP3
  PTP |= 0x0B;        // ...while disabling the other without other effects
  DDRP = 0x0F;        // enable the 7-segment control
  
  DDRH = 0x00;        // make all DIP switches/pushbuttons inputs

  for(;;){
    
    buttonDown = 0;
    while (buttonDown == 0)            
    {
      while ((PTH & 0x02) == 0x02){}    // wait until SW4 is pressed (low signal)
      for (i=0; i<DEBOUNCE; i++){}      // ... then wait for debounce time
      if ((PTH & 0x02) == 0) {          // ... and signal press if value is consistent
        buttonDown = 1;
      }      
    }
    
    PORTB = PORTB << 1;                 // modify 7-segment display to moce the lit
    if (PORTB == 0){                    // LED one location
      PORTB = 0x01;
    }
    
    
    buttonUp = 0;
    while (buttonUp == 0)
    {
      while ((PTH & 0x02) == 0){}        // wait until SW4 is released (high signal)
      for (i=0; i<DEBOUNCE; i++){}       // ... then wait for debounce time
      if ((PTH & 0x02) == 0x02) {        // ... and signal press if value is consistent
        buttonUp = 1;
      }      
    }
    
    
  }
  /* please make sure that you never leave main */
}
